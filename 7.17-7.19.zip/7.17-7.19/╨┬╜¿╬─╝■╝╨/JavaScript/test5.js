window.onload = function() {
    //创建对象实例：
    var lunbo = new ShowPic();
    lunbo.init();
    lunbo.leftArrow();
    lunbo.rightArrow();
}
var name,number=0;
//定义轮播对象
function ShowPic() {
    this.scatter1 = document.getElementsByClassName("scatter1");
    this.scatter2 = document.getElementsByClassName("scatter2");
    this.image = document.getElementsByClassName("image")[0];
    this.contain = document.getElementsByClassName("container")[0];
    this.arrow = document.getElementsByClassName("arrow");
    this.array = ["1.png","2.png","3.png","4.png"];
    this.i = 0;
    this.num = 0;
    this.number = 0;
    this.index = 0;
    this.timer = 0;
    this.flag = true;
    this.scatterNum = 0;
}
//初始化
ShowPic.prototype.init = function() {
    var This = this;
    for (This.i = 0; This.i<5; This.i++) {
        This.scatter1[This.i].getElementsByClassName("firstPage")[0].style.backgroundImage = "url(image/1.png)";
        This.scatter2[This.i].getElementsByClassName("firstPage")[0].style.backgroundImage = "url(image/1.png)";
        This.scatter1[This.i].getElementsByClassName("secondPage")[0].style.backgroundImage = "url(image/2.png)";
        This.scatter2[This.i].getElementsByClassName("secondPage")[0].style.backgroundImage = "url(image/2.png)";
    }
}
ShowPic.prototype.leftArrow = function() {
    var This = this;
    this.arrow[0].onclick = function() {
        if(This.flag) {
            This.flag = false;
            This.number = This.index;
            if(This.number == 0) {
                This.number = 4;
            }
            This.change(This.number - 1);
            setTimeout(function(){ 
                This.flag = true;
            }, 3000);
        }
    }
}
ShowPic.prototype.rightArrow = function() {
    var This = this;
    this.arrow[1].onclick = function() {
        if(This.flag) {
            This.flag = false;
            This.change((This.index+1)%4);
            setTimeout(function(){ 
                This.flag = true;
            }, 3000);
        }
    }  
}
ShowPic.prototype.change = function(nextNum) {
    var This = this;
    This.image.getElementsByTagName("li")[This.index].style.display = 'none';    // 将当前图片隐藏
    This.index = nextNum;
    for (This.i=0; This.i<5; This.i++) {
        (function(i) {
            This.scatter1[i].getElementsByClassName("secondPage")[0].style.backgroundImage = "url(image/"+This.array[nextNum]+")";
            This.scatter2[i].getElementsByClassName("secondPage")[0].style.backgroundImage = "url(image/"+This.array[nextNum]+")";
        })(This.i)
    }
    This.animation();
    setTimeout(function() {
        This.image.getElementsByTagName("li")[This.index].style.display = 'block';
        for (This.i=0; This.i<5; This.i++) {
            (function(i) {
                This.scatter1[i].getElementsByClassName("firstPage")[0].style.backgroundImage = "url(image/"+This.array[nextNum]+")";
                This.scatter2[i].getElementsByClassName("firstPage")[0].style.backgroundImage = "url(image/"+This.array[nextNum]+")";
            })(This.i)
        }
        This.removeAnimation();
    },3000); 
}
ShowPic.prototype.animation = function() {
    var This = this;
    if (This.scatterNum>=This.scatter1.length) {
        return false;
    }
    This.scatter1[This.scatterNum].style.animation = "change1 1.9s forwards";
    This.scatter2[This.scatterNum].style.animation = "change2 1.9s forwards";
    This.scatterNum++;
    setTimeout(This.animation.bind(This),100);
}
ShowPic.prototype.removeAnimation = function() {
    var This = this;
    for (This.i = 0;This.i<5;This.i++) {
        This.scatter1[This.i].style.animation = "";
        This.scatter2[This.i].style.animation = "";
    }
    This.scatterNum = 0;
}