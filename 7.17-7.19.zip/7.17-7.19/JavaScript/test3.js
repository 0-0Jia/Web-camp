window.onload = function() {
    //创建对象实例：
    var lunbo = new ShowPic();
    lunbo.leftArrow();
    lunbo.rightArrow();
    lunbo.autoPlay();
    lunbo.init();
}
//定义轮播对象
function ShowPic() {
    this.scatters1 = document.getElementsByClassName("scatter");     //上面的图片
    this.scatters2 = document.getElementsByClassName("scatter2");   //下面的图片
    this.container = document.getElementsByClassName("area")[0];
    this.arrow = document.getElementsByClassName("arrows");
    this.array = ["url(image/1.png)","url(image/2.png)","url(image/3.png)","url(image/4.png)"];
    // 下面两个计数量，一个是index,另外一个是degNum,第一个计算下一张反转图是哪一张，第二个是累加翻过的角度。
    this.i = 0;
    this.j = 0;
    this.index = 0;
    this.degNum = 0;
    this.flag = true;
    this.timer = 0;
}
//初始化
ShowPic.prototype.init = function() {
    var This = this;
    for (This.i=0; This.i<This.scatters1.length; This.i++) {
        This.scatters1[This.i].style.backgroundImage = This.array[0];
        This.scatters2[This.i].style.backgroundImage = This.array[1];
    }
    window.onblur = function() {
        clearInterval(This.timer);
    }
    window.onfocus = function() {
        window.location.reload();
    }
}
//左箭头：
ShowPic.prototype.leftArrow = function() {
    var This = this;
    this.arrow[0].onclick = function() {
        clearInterval(This.timer);
        This.degNum++;
        if(This.index == 0) {
            This.index = 4;
        }
        This.index--;
        for (This.j = 0; This.j < This.scatters1.length; This.j++) {
            This.scatters1[This.j].style.transform = "rotateX("+ This.degNum * 180 +"deg)";        // 叠加翻角度
            This.scatters2[This.j].style.transform = "rotateX("+ (This.degNum + 1) * 180+"deg)";
        }
        if(This.index % 2) {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                if (This.index == 3) {
                    This.scatters1[This.j].style.backgroundImage = This.array[0];
                    This.scatters2[This.j].style.backgroundImage = This.array[This.index];
                }else {
                    This.scatters1[This.j].style.backgroundImage = This.array[This.index+1];
                    This.scatters2[This.j].style.backgroundImage = This.array[This.index];
                }
            }
        }else {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                This.scatters2[This.j].style.backgroundImage = This.array[This.index+1];
                This.scatters1[This.j].style.backgroundImage = This.array[This.index];
            }
        }
        This.autoPlay();
    }
}
//右箭头：
ShowPic.prototype.rightArrow = function() {
    var This = this;
    this.arrow[1].onclick = function() {
        clearInterval(This.timer);
        This.degNum++;
        This.index = (This.index + 1) % 4;
        for (This.j = 0; This.j < This.scatters1.length; This.j++) {
            This.scatters1[This.j].style.transform = "rotateX("+ This.degNum * 180 +"deg)";        // 叠加翻角度
            This.scatters2[This.j].style.transform = "rotateX("+ (This.degNum + 1) * 180+"deg)";
        }
        if(This.index % 2) {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                This.scatters1[This.j].style.backgroundImage = This.array[This.index-1];
                This.scatters2[This.j].style.backgroundImage = This.array[This.index];
            }
        }else {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                This.scatters2[This.j].style.backgroundImage = This.array[This.index-1];
                This.scatters1[This.j].style.backgroundImage = This.array[This.index];
            }
        }
        This.autoPlay();
    }
}

//自动轮播：
ShowPic.prototype.autoPlay = function() {
    var This = this;
    This.flag == false;
    This.timer = setInterval(function() {
        This.degNum++;
        This.index = (This.index + 1) % 4;
        for (This.j = 0; This.j < This.scatters1.length; This.j++) {
            This.scatters1[This.j].style.transform = "rotateX("+ This.degNum * 180 +"deg)";        // 叠加翻角度
            This.scatters2[This.j].style.transform = "rotateX("+ (This.degNum + 1) * 180+"deg)";
        }
        if(This.index % 2) {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                This.scatters1[This.j].style.backgroundImage = This.array[This.index-1];
                This.scatters2[This.j].style.backgroundImage = This.array[This.index];
            }
        }else {
            for(This.j = 0; This.j < This.scatters1.length; This.j++) {
                This.scatters2[This.j].style.backgroundImage = This.array[This.index-1];
                This.scatters1[This.j].style.backgroundImage = This.array[This.index];
            }
        }
    },5000);
}