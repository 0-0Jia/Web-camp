window.onload = function() {
    //创建对象实例：
    var lunbo = new ShowPic();
    lunbo.leftArrow();
    lunbo.rightArrow();
    lunbo.autoPlay();
    lunbo.init();
}
//定义轮播对象
function ShowPic() {
    this.container = document.getElementsByClassName("Container")[0];
    this.images = document.getElementsByClassName("images");
    this.arrow = document.getElementsByClassName("arrows");
    this.i = 0;
    this.index = 0;
    this.count = 0;
    this.timer = 0;
    this.flag = true;
}
//初始化
ShowPic.prototype.init = function() {
    var This = this;
    for (This.i = 0; This.i < 5; This.i++) {
        This.images[This.i].className += " trasform" + This.i.toString();
    }
    This.container.onmouseover = function() {
        clearInterval(This.timer);
    }
    This.container.onmouseout = function() {
        This.autoPlay();
    }
}
//左箭头：
ShowPic.prototype.leftArrow = function() {
    var This = this;
    this.arrow[0].onclick = function() {
        if(This.flag) {
            clearInterval(This.timer);
            This.flag = false;
            if (This.count == 0) {
                This.count = 5;
            }
            This.count--;
            for (This.i = 0; This.i < 5; This.i++) {
                This.index = (This.i + This.count) % 5;
                This.images[This.i].className = "images trasform" + This.index.toString();
            }
            setTimeout(function() {
                This.flag = true;
            },1000)
        }
    }

}
//右箭头：
ShowPic.prototype.rightArrow = function() {
    var This = this;
    this.arrow[1].onclick = function() {
        if(This.flag) {
            clearInterval(This.timer);
            This.flag = false;
            if (This.count == 4) {
                This.count = -1;
            }
            This.count++;
            for (This.i = 0; This.i < 5; This.i++) {
                This.index = (This.i + This.count) % 5;
                This.images[This.i].className = "images trasform" + This.index.toString();
            }
            setTimeout(function() {
                This.flag = true;
            },1000)
        }
    } 
}
//自动轮播：
ShowPic.prototype.autoPlay = function() {
    var This = this;
    This.timer = setInterval(function() {
        if (This.count == 4) {
            This.count = -1;
        }
        This.count++;
        for (This.i = 0; This.i < 5; This.i++) {
            This.index = (This.i + This.count) % 5;
            This.images[This.i].className = "images trasform" + This.index.toString();
        }
    },2000);
}