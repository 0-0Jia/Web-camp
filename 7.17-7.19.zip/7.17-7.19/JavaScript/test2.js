window.onload = function() {
    //创建对象实例：
    var lunbo = new ShowPic();
    lunbo.init();
    lunbo.leftArrow();
    lunbo.rightArrow();
    lunbo.autoPlay();
}
//定义轮播对象
function ShowPic() {
    this.imageContainer = document.getElementsByClassName("imageContainer")[0];
    this.indexs = document.getElementsByClassName("indexs");
    this.IMG = document.getElementsByClassName("backgroundIMG");
    this.arrow = document.getElementsByClassName("arrows");
    this.i = 0;
    this.index = 0;
    this.timer = 0;
    this.len = 0;
}
//初始化
ShowPic.prototype.init = function() {
    var This = this;
    for (var j = 0; j < 5; j++) {
        This.IMG[j].style.opacity = 0;
    }
    This.IMG[0].style.opacity = 1;
    This.indexs[0].style.backgroundColor = "orange";
    This.imageContainer.onmouseover = function() {
        for (var j = 0; j < 2; j++) {
            This.arrow[j].style.opacity = 1;
        }
    }
    This.imageContainer.onmouseout = function() {
        This.timer = setInterval(This.autoPlay, 2500);
        for (var j = 0; j < 2; j++) {
            This.arrow[j].style.opacity = 0;
        }
    }
}
//左箭头：
ShowPic.prototype.leftArrow = function() {
    var This = this;
    this.arrow[0].onclick = function() {
        clearInterval(This.timer);
        This.IMG[This.index].style.opacity = 0;
        This.indexs[This.index].style.backgroundColor = "";
        if(This.index == 0){
            This.index = 4;
        }else {
            This.index = (This.index - 1) % 5;
        }
        This.IMG[This.index].style.opacity = 1;
        This.indexs[This.index].style.backgroundColor = "orange";
        This.timer = setInterval(This.autoPlay, 2500);
    }
}
//右箭头：
ShowPic.prototype.rightArrow = function() {
    var This = this;
    this.arrow[1].onclick = function() {
        clearInterval(This.timer);
        This.IMG[This.index].style.opacity = 0;
        This.indexs[This.index].style.backgroundColor = "";
        This.index = (This.index + 1) % 5;
        This.IMG[This.index].style.opacity = 1;
        This.indexs[This.index].style.backgroundColor = "orange";
        This.timer = setInterval(This.autoPlay, 2500);
    }
}

//自动轮播：
ShowPic.prototype.autoPlay = function() {
    var This = this;
    This.timer = setInterval(function() {
        This.IMG[This.index].style.opacity = 0;
        This.indexs[This.index].style.backgroundColor = "";
        This.index = (This.index + 1) % 5;
        This.IMG[This.index].style.opacity = 1;
        This.indexs[This.index].style.backgroundColor = "orange";
    },4000);
}