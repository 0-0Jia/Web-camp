window.onload = function() {
    //创建对象实例：
    var lunbo = new ShowPic();
    lunbo.leftArrow();
    lunbo.rightArrow();
    lunbo.autoPlay();
    lunbo.init();
}
//定义轮播对象
function ShowPic() {
    this.backgroundImages = document.getElementsByClassName("backgroundImages")[0];
    this.backgroundImg = document.getElementsByClassName("background");
    this.arrow = document.getElementsByClassName("arrows");
    this.i = 0;
    this.len = this.backgroundImg.length;
    this.num = 0;
    this.timer = 0;
    this.translateX = 0;
}
//初始化
ShowPic.prototype.init = function() {
    var This = this;
    for (i = 0; i < 2; i++) {
        This.arrow[i].onmouseover = function () {
            for (var j=0;j<2;j++) {
                This.arrow[j].style.opacity = 1;
            }
        }
    }
    This.backgroundImages.onmouseover = function() {
        for (var j = 0; j < 2; j++) {
            This.arrow[j].style.opacity = 1;
        }
    }
    This.backgroundImages.onmouseout = function() {
        for (var j = 0; j < 2; j++) {
            This.arrow[j].style.opacity = 0;
        }
    }
}
//左箭头：
ShowPic.prototype.leftArrow = function() {
    var This = this;
    this.arrow[0].onclick = function() {
        clearInterval(This.timer);
        This.translateX = -500 * This.num;
        This.translateX = This.translateX.toString();
        if(This.num == This.len-1) {
            This.num = 5;
            This.backgroundImages.style.transform = "translateX( "+ This.translateX +"px)";
        }
        else if(This.num == 0) {
            This.num = 5;
            This.backgroundImages.style.transform = "translateX(-2500px)";
        }
        else {
            This.num--;
            This.backgroundImages.style.transform = "translateX("+ This.translateX +"px)";
        }
        This.backgroundImages.style.transition = "all 1s ease";
        This.autoPlay();
    }
}
//右箭头：
ShowPic.prototype.rightArrow = function() {
    var This = this;
    this.arrow[1].onclick = function() {
        clearInterval(This.timer);
        This.translateX = -500 * This.num;
        This.translateX = This.translateX.toString();
        if(This.num == This.len-1) {
            This.num = 1;
            This.backgroundImages.style.transform = "translateX(-2500px)";
        }
        else if(This.num == 0) {
            This.num = 2;
            This.backgroundImages.style.transform = "translateX(-1000px)";
        }
        else {
            This.num++;
            This.backgroundImages.style.transform = "translateX("+ This.translateX +"px)";
        }
        This.backgroundImages.style.transition = "all 1s ease";
        This.autoPlay();
    }
}

//自动轮播：
ShowPic.prototype.autoPlay = function() {
    var This = this;
    This.timer = setInterval(function() {
        This.translateX = -500 * This.num;
        This.translateX = This.translateX.toString();
        if(This.num == This.len-1) {
            This.num = 1;
            This.backgroundImages.style.transform = "translateX(-2500px)";
        }
        else if(This.num == 0) {
            This.num = 2;
            This.backgroundImages.style.transform = "translateX(-1000px)";
        }
        else {
            This.num++;
            This.backgroundImages.style.transform = "translateX("+ This.translateX +"px)";
        }
        This.backgroundImages.style.transition = "all 1s ease";
    },3000);
}